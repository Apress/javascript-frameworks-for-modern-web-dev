# Angular Example 001 - "Hello, world!"

- Install npm dependencies: `$ npm install`
- Install Bower dependencies: `$ bower install`
- Launch the server by running the default grunt task: `$ grunt`
