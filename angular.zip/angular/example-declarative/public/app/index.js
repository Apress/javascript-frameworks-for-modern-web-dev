'use strict';
/* global angular */

var app = angular.module('app', []);

app.controller('ExampleController', function($scope) {
    $scope.message = 'Hello, world!';
});

app.run(function($log) {
    $log.debug('App is running');
});
