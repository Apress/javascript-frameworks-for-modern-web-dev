'use strict';

module.exports = function(grunt) {

    grunt.registerTask('server', function() {

        var open = require('open');
        var done = this.async();
        var express = require('express');
        var app = express();

        app.use('/', express.static('public'));
        app.use('/build', express.static('build'));

        app.listen(7000);

        grunt.log.ok('Project is now available at: http://localhost:%s', 7000);

        open('http://localhost:7000');

    });

};
