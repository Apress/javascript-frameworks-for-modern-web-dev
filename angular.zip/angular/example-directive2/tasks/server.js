'use strict';

var feed = require('feed-read');
var async = require('async');
var _ = require('lodash');

module.exports = function(grunt) {

    grunt.registerTask('server', function() {

        var open = require('open');
        var done = this.async();
        var express = require('express');
        var app = express();

        app.use('/', express.static('public'));
        app.use('/build', express.static('build'));

        app.route('/api/news')
            .get(function(req, res, next) {
                async.parallel([
                    function(cb) {
                        feed('http://www.npr.org/rss/rss.php?id=1001', function(err, result) {
                            cb(err, result);
                        });
                    },
                    function(cb) {
                        feed('http://feeds.theonion.com/theonion/daily', function(err, result) {
                            cb(err, result);
                        });
                    }
                ], function(err, result) {
                    if (err) return next(err);
                    var npr = result[0];
                    var onion = result[1];
                    while (onion.length) {
                        var index = _.findLastIndex(npr, function(row) {
                            return (row.feed.name === 'The Onion');
                        });
                        index = index + 2;
                        var item = onion.pop();
                        npr.splice(index, 0, item);
                    }
                    _.each(npr, function(row) {
                        if (row.feed.name === 'The Onion') {
                            row.img = '/img/onion.png';
                        } else {
                            row.img = '/img/npr.png';
                        }
                    });
                    res.send(npr);
                });
            });

        app.listen(7000);

        grunt.log.ok('Project is now available at: http://localhost:%s', 7000);

        open('http://localhost:7000');

    });

};
