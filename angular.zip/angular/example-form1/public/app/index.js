'use strict';
/* global angular */

var app = angular.module('app', []);
app.controller('formController', function($scope, $http, $log) {

    $scope.formClass = null;
    $scope.model = {};

    $http.get('/api/model').then(function(result) {
        $scope.model = result.data;
    });

    $scope.submit = function() {
        if (!$scope.myForm.$valid) return;
        $http.post('/api/model', {
            'model': $scope.model
        }).then(function() {
            alert('Form submitted.');
        }).catch(function(err) {
            alert(err);
        });
    };

    $scope.reset = function() {
        $scope.model = {};
        $http.post('/api/model', {
            'model': $scope.model
        });
    };

    /**
     * Angular's built-in `$watch()` method (available within every controller)
     * enables us to watch for and respond to changes that occur within variables
     * defined at the `$scope` level. Here we save the contents of our a form as
     * a JSON string to `$scope.output`, which is referenced by our template.
     */
    $scope.$watch('model', function() {
        $scope.output = angular.toJson($scope.model, 4);
    }, true);

});
