'use strict';

module.exports = function(grunt) {

    grunt.loadNpmTasks('grunt-contrib-compass');

    grunt.config('compass', {
        'dist': {
            'options': {
                'sassDir': 'sass',
                'cssDir': 'public/css'
            }
        }
    });

};
