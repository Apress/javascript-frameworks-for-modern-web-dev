'use strict';
/* global angular */

var app = angular.module('app', []);
app.controller('formController', function($scope, $http, $log) {

    $scope.formClass = null;
    $scope.model = {};

    $http.get('/api/model').then(function(result) {
        $scope.model = result.data;
    });

    $scope.submit = function() {
        if (!$scope.myForm.$valid) return;
        $http.post('/api/model', {
            'model': $scope.model
        }).then(function() {
            alert('Form submitted.');
        }).catch(function(err) {
            alert(err);
        });
    };

    $scope.reset = function() {
        $scope.model = {};
        $http.post('/api/model', {
            'model': $scope.model
        });
    };

    $scope.$watch('model', function() {
        $scope.output = angular.toJson($scope.model, 4);
    }, true);

});
