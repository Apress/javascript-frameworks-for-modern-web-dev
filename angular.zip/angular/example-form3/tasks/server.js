'use strict';

module.exports = function(grunt) {

    grunt.registerTask('server', function() {

        var model = {
            'pets': []
        };
        var open = require('open');
        var done = this.async();
        var express = require('express');
        var bodyParser = require('body-parser');
        var app = express();
        app.use(bodyParser.json({
            'type': 'application/json'
        }));

        app.use('/', express.static('public'));

        app.route('/api/model')
            .get(function(req, res, next) {
                res.send(model);
            })
            .post(function(req, res, next) {
                model = req.body.model;
                res.status(200).end();
            });

        app.listen(7000);

        grunt.log.ok('Project is now available at: http://localhost:%s', 7000);

        open('http://localhost:7000');

    });

};
