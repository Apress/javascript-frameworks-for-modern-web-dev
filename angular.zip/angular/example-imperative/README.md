# Imperative web application example

- Install npm dependencies: `$ npm install`
- Install Bower dependencies: `$ bower install`
- Launch the server by running the default grunt task: `$ grunt`
