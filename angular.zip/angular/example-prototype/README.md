# Prototype Example

Simple run:

```
$ node index.js
```
