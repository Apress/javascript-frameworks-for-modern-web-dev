// example-prototype/index.js

function Dog() {
}

Dog.prototype.bark = function() {
	console.log('Dog is barking.');
};

Dog.prototype.wag = function() {
	console.log('Tail is wagging.');
};

Dog.prototype.run = function() {
	console.log('Dog is running.');
};

var dog = new Dog();
dog.bark();
dog.wag();
dog.run();
