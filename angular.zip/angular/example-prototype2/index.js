'use strict';

/**
 * @class Vehicle
 */
var Vehicle = function Vehicle() {
    console.log(this.constructor.name, 'says: I am a vehicle.');
};

Vehicle.prototype.start = function() {
    console.log('%s has started.', this.constructor.name);
};

Vehicle.prototype.stop = function() {
    console.log('%s has stopped.', this.constructor.name);
};

/**
 * @class Car
 */
var Car = function Car() {
    console.log(this.constructor.name, 'says: I am a car.');
    Vehicle.apply(this, arguments);
};

Car.prototype = Object.create(Vehicle.prototype);
Car.prototype.constructor = Car;

Car.prototype.honk = function() {
    console.log('%s has honked.', this.constructor.name);
};

var vehicle = new Vehicle();
vehicle.start();
vehicle.stop();

var car = new Car();
car.start();
car.honk();
car.stop();

/* Result:
Vehicle says: I am a vehicle.
Vehicle has started.
Vehicle has stopped.
Car says: I am a car.
Car says: I am a vehicle.
Car has started.
Car has honked.
Car has stopped.
*/
