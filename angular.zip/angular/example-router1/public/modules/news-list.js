'use strict';
/* global angular */

var newsList = angular.module('newsList', []);

newsList.directive('newsList', function() {
    return {
        'restrict': 'E',
        'replace': true,
        'controller': function($scope, headlines) {
            headlines.fetch().then(function(items) {
                $scope.items = items;
            });
        },
        'templateUrl': '/templates/news-list.html'
    };
});

newsList.factory('headlines', function($http) {
    return {
        'fetch': function() {
            return $http.get('/api/news').then(function(result) {
                return result.data;
            });
        }
    };
});
