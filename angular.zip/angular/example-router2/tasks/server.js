'use strict';

var _ = require('lodash');

module.exports = function(grunt) {

    grunt.registerTask('server', function() {

        var open = require('open');
        var done = this.async();
        var express = require('express');
        var app = express();
        var animals = [
            {
                'id': 1,
                'label': 'cats'
            },
            {
                'id': 2,
                'label': 'dogs'
            },
            {
                'id': 3,
                'label': 'aardvarks'
            },
            {
                'id': 4,
                'label': 'hamsters'
            },
            {
                'id': 5,
                'label': 'squirrels'
            }
        ];

        app.use('/', express.static('public'));

        app.route('/api/animals')
            .get(function(req, res, next) {
                res.send(animals);
            });

        app.route('/api/animals/:animalID')
            .get(function(req, res, next) {
                req.params.animalID = parseInt(req.params.animalID, 10);
                var animal = _.findWhere(animals, {
                    'id': req.params.animalID
                });
                if (!animal) return res.status(404).end();
                res.send(animal);
            });

        app.route('/api/colors')
            .get(function(req, res, next) {
                res.send(colors);
            });

        app.listen(7000);

        grunt.log.ok('Project is now available at: http://localhost:%s', 7000);

        open('http://localhost:7000');

    });

};
