'use strict';

module.exports = {
  notifyPasswordChanged: function (email, cb) {
    cb(null);
  }
};