'use strict';

module.exports = {
  snoop: function (email, password, cb) {
    cb(null);
  }
};