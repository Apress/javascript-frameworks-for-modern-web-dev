# Bower Example

Run:

```
$ npm install
$ bower install
$ grunt
```
