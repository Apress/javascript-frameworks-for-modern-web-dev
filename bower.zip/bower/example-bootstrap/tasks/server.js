'use strict';

var express = require('express');
var open = require('open');
var app = express();

module.exports = function(grunt) {

    grunt.registerTask('server', function() {
        var done = this.async();
        app.use('/', express.static('public'));
        app.listen(7000);
        grunt.log.ok('Project is now available at: http://localhost:%s', 7000);
        open('http://localhost:7000');
    });

};
