# Browserify - Advanced Example

## Compiling the Application via Browserify's API

```
$ grunt browserify
```
