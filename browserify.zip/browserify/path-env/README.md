# Demonstration of Node's Support for the NODE_PATH Environment Variable

```
$ npm start
```
