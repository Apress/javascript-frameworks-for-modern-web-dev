# RequireJS Example

Launch the project with:

```
$ npm start
```
