'use strict';

define(['weather'], function(weather) {
    weather.getForecast();
});
