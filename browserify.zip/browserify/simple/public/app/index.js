'use strict';

var weather = require('./weather');
weather.getForecast();
