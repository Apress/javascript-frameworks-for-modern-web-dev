'use strict';

module.exports = {
    'getForecast': function() {
        document.getElementById('forecast').innerHTML = 'Forecast: Partly cloudy.';
    }
};
