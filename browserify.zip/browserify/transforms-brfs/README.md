# Browserify - Transforms Example (brfs)

## Starting the Application

```
$ npm start
```
