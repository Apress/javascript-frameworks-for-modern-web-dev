'use strict';

module.exports = function($scope) {

    $scope.animals = [
        'Aardvarks', 'Cats', 'Dogs', 'Elephants', 'Lemurs', 'Three-Toed Sloths', 'Zebras'
    ];

};
