'use strict';

var Foo = require('./vendor/foo');
console.log('Foo', Foo);
new Foo();
