# Faye Example

This project implements a web application that allows registered users to sign in and test various aspects of Faye's
functionality. It builds on topics that were covered in previous chapters (AngularJS, Knex, and Bookshelf). If you do not
already have the `knex` command-line utility installed, you can install it with:

```
$ npm install -g knex
```

Next, run:

```
$ npm start
```

Afterwards, you can sign in using the following usernames / passwords:

- john.doe / 123
- jane.doe / 123
