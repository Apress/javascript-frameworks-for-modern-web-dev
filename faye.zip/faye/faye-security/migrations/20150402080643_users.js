'use strict';

exports.up = function(knex, Promise) {
    return knex.schema.createTable('users', function(table) {
        table.increments().unsigned().primary().notNullable();
        table.integer('account_id').unsigned().references('accounts.id').notNullable().onDelete('cascade');
        table.string('username').unique().notNullable();
        table.string('token').unique();
        table.string('password_hash').notNullable();
        table.timestamp('created_at').defaultTo(knex.fn.now()).notNullable();
        table.timestamp('updated_at').defaultTo(knex.fn.now()).notNullable();
    });
};

exports.down = function(knex, Promise) {
    return knex.schema.dropTable('users');
};
