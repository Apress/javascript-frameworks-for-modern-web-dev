'use strict';
/* global $, Faye, angular */

var app = angular.module('app', [
    'ngRoute'
]);

app.config(function($routeProvider, $httpProvider) {

    $httpProvider.defaults.transformRequest = function(data, headersGetter) {
        data = data || {};
        var headers = headersGetter();
        headers.authorization = $.cookie('token');
        return JSON.stringify(data);
    };

    $routeProvider.when('/login', {
        'controller': function($scope, $http, $location) {

            $scope.model = {
                'username': null,
                'password': null
            };

            $scope.login = function() {
                if (!$scope.loginForm.$valid) return;
                $http.post('/api/auth', $scope.model)
                .then(function(result) {
                    $.cookie('token', result.data.token, { 'path': '/' });
                    $location.path('/messages');
                })
                .catch(function(err) {
                    alert('Unable to sign in. Please try again.');
                });
            };

            if ($.cookie('token')) $location.path('/messages');

        },
        'templateUrl': '/templates/login.html'
    });

    $routeProvider.when('/messages', {
        'controller': function($scope, $http, $location, $rootScope, token, me, faye) {

            $scope.faye = faye.client;

            $scope.model = {
                'subscriptions': faye.subscriptions,
                'messages': [],
                'channel': null,
                'publish_channel': null,
                'publish_message': null
            };

            // Subscribe to channels pertaining to the user's account
            faye.client.subscribe('/accounts/' + me.account_id + '/**');
            // Subscribe to channels pertaining directly to the user
            faye.client.subscribe('/users/' + me.id + '/**');

            $scope.subscribe = function() {
                if (!$scope.subscriptionForm.$valid) return;
                faye.client.subscribe($scope.model.channel);
                $scope.model.channel = null;
            };

            $scope.unsubscribe = function(subscription) {
                faye.client.unsubscribe(subscription);
            };

            $scope.publish = function() {
                if (!$scope.publishForm.$valid) return;
                var data;
                try {
                    data = JSON.parse($scope.model.publish_message);
                    faye.client.publish($scope.model.publish_channel, data);
                    $scope.model.publish_channel = null;
                    $scope.model.publish_message = null;
                } catch(e) {
                    alert('Please enter a valid JSON string');
                }
            };

            $scope.$on('faye.incoming', function(e, message) {
                $scope.model.messages.push({
                    'data': 'Channel: ' + message.channel + "\n\n" + JSON.stringify(message.data, null, 4) + "\n"
                });
                if (!$rootScope.$$phase) $rootScope.$apply();
            });

            $scope.logout = function() {
                $http.post('/api/logout')
                    .then(function() {
                        $.removeCookie('token', {
                            'path': '/'
                        });
                        $location.path('/login');
                    });
            };

        },
        'templateUrl': '/templates/messages.html',
        'resolve': {
            'token': function($location) {
                if (!$.cookie('token')) return $location.path('/login');
                return $.cookie('token');
            },
            'me': function($http, $location) {
                return $http.get('/api/me')
                    .then(function(result) {
                        return result.data;
                    })
                    .catch(function(err) {
                        $.removeCookie('token', {
                            'path': '/'
                        });
                        $location.path('/login');
                    });
            }
        }
    });

    $routeProvider.otherwise({
        'redirectTo': '/login'
    });

});

app.factory('faye', function($rootScope) {

    var client = new Faye.Client('http://localhost:7000/faye');

    var result = {
        'client': client,
        'subscriptions': []
    };

    client.addExtension({
        'incoming': function(message, callback) {
            switch (message.channel) {
                case '/meta/subscribe':
                    if (message.successful) {
                        result.subscriptions.push(message.subscription);
                        if (!$rootScope.$$phase) $rootScope.$apply();
                    } else {
                        alert('Error subscribing to ' + message.subscription + ': ' + message.error);
                    }
                break;
                case '/meta/unsubscribe':
                    if (message.successful) {
                        var idx = result.subscriptions.indexOf(message.subscription);
                        result.subscriptions.splice(idx, 1);
                        if (!$rootScope.$$phase) $rootScope.$apply();
                    }
                break;
            }
            if (message.channel.indexOf('/meta') === 0) return callback(message);
            if (message.data) {
                $rootScope.$broadcast('faye.incoming', message);
            }
            callback(message);
        },
        'outgoing': function(message, callback) {
            message.ext = message.ext || {};
            message.ext.token = $.cookie('token');
            callback(message);
            if (!$rootScope.$$phase) $rootScope.$apply();
        }
    });

    return result;

});
