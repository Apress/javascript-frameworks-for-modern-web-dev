'use strict';

exports.seed = function(knex, Promise) {
    return Promise.join(
        knex('users').del(),
        knex('users').insert([
            {
                'id': 1,
                'account_id': 1,
                'username': 'john.doe',
                'password_hash': '$2a$10$fD4vSGQ8H3OnCkWkUcZiLuhFFJJ2NQ9bfhj9BmaoqCFzCFHbWwMbq' // '123'
            },
            {
                'id': 2,
                'account_id': 2,
                'username': 'jane.doe',
                'password_hash': '$2a$10$fD4vSGQ8H3OnCkWkUcZiLuhFFJJ2NQ9bfhj9BmaoqCFzCFHbWwMbq' // '123'
            }
        ])
    );
};
