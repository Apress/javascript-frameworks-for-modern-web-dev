'use strict';

var open = require('open');

module.exports = function(grunt) {

    grunt.config('express', {
        'port': 7000
    });

    grunt.registerTask('express', function() {
        var done = this.async();
        var app = require('../lib/server');
        console.log('App is now available at: http://localhost:%s', grunt.config('express.port'));
        open('http://localhost:' + grunt.config('express.port'));
    });

};
