'use strict';

module.exports = function(grunt) {

    /**
     * Migrates the database to a specified migration point.
     *
     * @example $ grunt seed
     */
    grunt.registerTask('seed', 'Import Knex seed data', function() {

        var done = this.async();
        var knex = require('../lib/db/knex');

        knex('users').count('id AS count')
            .then(function(res) {

                if (!res[0].count) {

                    grunt.util.spawn({
                        'cmd': 'knex',
                        'args': [
                            'seed:run'
                        ]
                    }, function(err, result) {
                        if (err) {
                            return grunt.fail.fatal(err);
                        }
                        grunt.verbose.writeln(result);
                        done();
                    });

                } else {

                    done();

                }

            })
            .catch(function(err) {
                grunt.fail.fatal(err);
            });

    });

};
