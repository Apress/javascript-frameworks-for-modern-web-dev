# Faye Example

    $ npm start
