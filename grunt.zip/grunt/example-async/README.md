# Grunt Example

- Install npm dependencies: `$ npm install`
- Run the default Grunt task: `$ grunt`
