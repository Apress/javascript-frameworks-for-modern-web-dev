'use strict';

module.exports = function(grunt) {

    grunt.config('release-name-generator', {
        'options': {
        },
        'development': {
        },
        'production': {
        }
    });

    grunt.loadTasks('tasks');

};
