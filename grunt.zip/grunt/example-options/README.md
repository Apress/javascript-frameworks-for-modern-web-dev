# Grunt Example

- Install npm dependencies: `$ npm install`
- Run the `count` Grunt task (same as default): `$ grunt count --limit=5`
