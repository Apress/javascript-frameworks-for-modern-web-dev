# Grunt Example

- Install npm dependencies: `$ npm install`
- Run the default Grunt task: `$ grunt`
- Run the `uglify` Grunt task (same as default): `$ grunt uglify`
- Run the `hello_world` Grunt task: `$ grunt hello_world`
