'use strict';

window.MyApp = function() {

    console.log('Welcome to MyApp.');
    var lib = new MyLib();

};
