'use strict';

window.MyLib = function() {

    return {
        'doSomething': function() {
            console.log('Things are happening.');
        }
    };

};
