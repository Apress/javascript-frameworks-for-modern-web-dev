# Grunt Example

- Install npm dependencies: `$ npm install`
- Run the default Grunt task: `$ grunt`
- Attempt to run the `step-two` task directly: `$ grunt step-two`
