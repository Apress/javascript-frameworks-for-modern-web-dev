'use strict';

module.exports = function(grunt) {
    grunt.registerTask('step-one', function() {
        console.log('Step One');
    });
};
