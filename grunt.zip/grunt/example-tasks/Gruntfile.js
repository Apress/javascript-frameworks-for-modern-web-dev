'use strict';

module.exports = function(grunt) {
    grunt.loadTasks('tasks');
};
