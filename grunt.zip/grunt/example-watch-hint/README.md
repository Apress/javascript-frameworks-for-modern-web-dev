# Grunt Example

- Install npm dependencies: `$ npm install`
- Run the default Grunt task: `$ grunt`

As changes occur within the `src` folder, Grunt will automatically run the `jshint` task - notifying you of any errors that it encounters.
