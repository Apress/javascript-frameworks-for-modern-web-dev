'use strict';

/**
 * @class MyApp
 */
var MyApp = function MyApp() {
    console.log('Welcome to MyApp');
};
