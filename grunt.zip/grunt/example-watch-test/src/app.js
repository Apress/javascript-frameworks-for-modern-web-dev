'use strict';

var App = function App() {

    this.add = function(a, b) {
        return a + b;
    };

};

module.exports = App;
