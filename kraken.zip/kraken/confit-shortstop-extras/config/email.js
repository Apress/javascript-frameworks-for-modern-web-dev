'use strict';

module.exports = {
    'hostname': 'smtp.myapp.com',
    'username': 'user',
    'password': 'pass',
    'from': 'My Application <noreply@myapp.com>'
};
