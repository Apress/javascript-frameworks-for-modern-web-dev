# Confit Example

Install npm dependencies:

```
$ npm install
```

Execute `index.js`:

```
$ node index.js
```
