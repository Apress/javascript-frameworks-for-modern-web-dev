```
$ npm install
$ node index
```
