'use strict';

var accounts = [
	{
		'id': 1,
		'name': 'Acme Anvil Company'
	},
	{
		'id': 2,
		'name': 'Dewey, Cheatem & Howe'
	}
];

module.exports = accounts;
