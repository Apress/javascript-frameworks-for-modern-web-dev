'use strict';

var users = [
	{
		'id': 1,
		'first_name': 'John',
		'last_name': 'Doe'
	},
	{
		'id': 2,
		'first_name': 'Jane',
		'last_name': 'Doe'
	}
];

module.exports = users;
