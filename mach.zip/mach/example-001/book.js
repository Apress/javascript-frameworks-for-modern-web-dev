'use strict';

function Book(title, author) {
  this.id = 0;
  this.title = title || '';
  this.author = author || '';
  this.publisher = '';
  this.publicationDate = null;
  this.series = {};
}

Book.fromParams = function (params) {
  var book = new Book(params.title, params.author);
  book.publisher = params.publisher;
  book.publicationDate = params.publicationDate;

  if (params.seriesTitle) {
    book.series.title = params.seriesTitle;
  }

  if (params.seriesPosition) {
    book.series.position = params.seriesPosition;
  }

  return book;
};

module.exports = Book;