'use strict';

module.exports = [
  {
    id: 1,
    title: 'God Emperor of Dune',
    author: 'Frank Herbert',
    series: {
      title: 'Dune Chronicles',
      position: 4
    },
    publisher: 'Victor Gollancz',
    publicationDate: new Date(2003, 2, 13)
  },
  {
    id: 2,
    title: 'Wizard\'s First Rule',
    author: 'Terry Goodkind',
    series: {
      title: 'Sword of Truth',
      position: 1
    },
    publisher: 'Tor',
    publicationDate: new Date(2010, 8, 14)
  },
  {
    id: 3,
    title: 'Dust',
    author: 'Hugh Howey',
    series: {
      title: 'Silo',
      position: 3
    },
    publisher: 'Broad Reach Publishing',
    publicationDate: new Date(2013, 7, 17)
  },
  {
    id: 4,
    title: 'The Last Wish',
    author: 'Andrzej Sapkowski',
    series: {
      title: 'The Witcher Saga',
      position: 1
    },
    publisher: 'Orbit',
    publicationDate: new Date(2008, 11, 14)
  },
  {
    id: 5,
    title: 'The Name of the Wind',
    author: 'Patrick Rothfuss',
    series: {
      title: 'The Kingkiller Chronicle',
      position: 1
    },
    publisher: 'DAW',
    publicationDate: new Date(2007, 2, 27)
  },
  {
    id: 6,
    title: 'The Fall of Hyperion',
    author: 'Dan Simmons',
    series: {
      title: 'Hyperion Cantos',
      position: 2
    },
    publisher: 'Spectra',
    publicationDate: new Date(1995, 10, 1)
  },
  {
    id: 7,
    title: 'The Briar King',
    author: 'J. Gregory Keyes',
    series: {
      title: 'Kingdoms of Thorn and Bone',
      position: 1
    },
    publisher: 'Ballantine Books',
    publicationDate: new Date(2002, 10, 1)
  },
  {
    id: 8,
    title: 'The Blade Itself',
    author: 'Joe Abercrombie',
    series: {
      title: 'The First Law',
      position: 1
    },
    publisher: 'Gollancz',
    publicationDate: new Date(2006, 4, 4)
  },
  {
    id: 9,
    title: 'Wool Omnibus',
    author: 'Hugh Howey',
    series: {
      title: 'Silo',
      position: 1
    },
    publisher: 'Broad Reach Publishing',
    publicationDate: new Date(2012, 0, 25)
  }
];