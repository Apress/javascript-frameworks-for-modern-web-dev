'use strict';
var books = require('./books');
var authors = require('./authors');

function findOne(collection, predicate, cb) {
  process.nextTick(function () {
    var index = 0, len = collection.length;
    while (index < len) {
      var item = collection[index];
      if (predicate(item)) {
        return cb(null, item);
      }
      index += 1;
    }
    cb(null, null);
  });
}

function findMany(collection, predicate, cb) {
  process.nextTick(function () {
    var index = 0, len = collection.length;
    var results = [];
    while (index < len) {
      var item = collection[index];
      if (predicate(item)) {
        results.push(item);
      }
      index += 1;
    }
    cb(null, results);
  });
}

function upsert(collection, item, predicate, cb) {
  var newID = (collection.length + 1);
  // insert
  if (arguments.length === 3) {
    cb = predicate;
    item.id = newID;
    collection.push(item);
    cb(null, newID, true);
  }
  process.nextTick(function () {
    // update
    var index = 0, len = collection.length;
    while (index < len) {
      var oldItem = collection[index];
      if (predicate(oldItem)) {
        collection[index] = item;
        return cb(null, item.id, false);
      }
      index += 1;
    }
    // item not found, insert
    item.id = newID;
    collection.push(item);
    cb(null, newID, true);
  });
}

function remove(collection, predicate, cb) {
  process.nextTick(function () {
    var index = 0, len = collection.length;
    while (index < len) {
      var item = collection[index];
      if (predicate(item)) {
        collection.splice(index, 1);
        /*
         * recurse using the spliced collection to
         * reset the while loop index count; accumulate
         * the result count before triggering the callback
         */
        return remove(collection, predicate, function (err, count) {
          cb(err, (count || 0) + 1);
        });
      }
      index += 1;
    }
    /*
     * exited the loop without performing a splice,
     * so result count = 0
     */
    return cb(null, 0);
  });
}

module.exports = {
  book: {
    findByID: function (id, cb) {
      findOne(books, function (book) {
        return book.id === id;
      }, cb);
    },

    find: function (predicate, cb) {
      findMany(books, predicate, cb);
    },

    all: function (cb) {
      cb(null, books);
    },

    save: function (book, cb) {
      upsert(books, book, function willUpdate (oldBook) {
        return book.hasOwnProperty('id') &&
          oldBook.id === book.id;
      }, function (err, id, isNew) {
        if (err) return cb(err);
        cb(null, {id: id, isNew: isNew});
      });
    },

    remove: function (id, cb) {
      remove(books, function (book) {
        return book.id === id;
      }, function (err, affectedCount) {
        if (err) return cb(err);
        cb(null, {removed: affectedCount});
      });
    }
  },

  author: {
    findByGenre: function (genre, cb) {
      findMany(authors, function (author) {
        return author.genres.indexOf(genre) > -1;
      }, cb);
    },

    findBooks: function (authorName, cb) {
      findMany(books, function (book) {
        return book.author === authorName;
      }, cb);
    }
  }
};
