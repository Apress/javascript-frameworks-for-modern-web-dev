#!/usr/bin/env bash

# get a list of books
#curl -X GET http://localhost:8080/book

# get a book by ID (url parameter)
#curl -X GET http://localhost:8080/book/2

# get author(s) by genre (query string)
#curl -X GET http://localhost:8080/author?genre=Horror

# post a new book
#curl -X POST http://localhost:8080/book \
#    -H "Content-Type: application/x-www-form-urlencoded" \
#    -d "title=Leviathan%20Wakes&author=James%20S.A.%20Corey&publisher=Orbit&publicationDate=2011-06-15T05%3A00%3A00.000Z"

# post a new book (json)
#curl -X POST http://localhost:8080/book \
#    -H "Content-Type: application/json" \
#    -d @new-book.json