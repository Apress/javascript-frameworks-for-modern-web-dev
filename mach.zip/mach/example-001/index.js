'use strict';
var mach = require('mach');
var Q = require('q');
var swig = require('swig');
var xmlify = require('./xmlify');
var db = require('./db');
var Book = require('./book');

// create a stack
var app = mach.stack();

// add some middleware
app.use(mach.logger);

// add some routes

app.get('/book', function (conn) {
  /*
   * 1. Routes return promises. Q can adapt the callback-
   * driven database module so that its result (or error)
   * is passed through a promise chain. The makeNodeResolver()
   * method will provide a callback to feed the deferred.
   */
  var deferred = Q.defer();
  db.book.all(deferred.makeNodeResolver());
  /*
   * 2. Adding handlers to the promise chain by calling
   * promise.then().
   */
  return deferred.promise.then(function (books) {
    /*
     * 3. The Connection.json() method returns a promise.
     * The HTTP status code will be sent as an HTTP header
     * in the response, and the array of books will be
     * serialized as JSON.
     */
    return conn.json(200, books);
  }, function (err) {
    /*
     * 4. An HTTP 500 will be delivered to the client on
     * error. The error's message will be used in the
     * serialized JSON response.
     */
    return conn.json(500, {error: err.message});
  });
});

app.get('/book/:id', function (conn) {
  var id = Number(conn.params.id);
  var deferred = Q.defer();
  db.book.findByID(id, deferred.makeNodeResolver());
  return deferred.promise.then(function (book) {
    if (!book) {
      return conn.json(404);
    }
    return conn.json(200, book);
  }, function (err) {
    return conn.json(500, {error: err.message});
  });
});

app.post('/book', function (conn) {
  return conn.getParams({
    title: String,
    author: String,
    seriesTitle: String,
    seriesPosition: Number,
    publisher: String,
    publicationDate: Date
  }).then(function (params) {
    var book = Book.fromParams(params);
    var deferred = Q.defer();
    db.book.save(book, deferred.makeNodeResolver());
    return deferred.promise.then(function (result) {
      return conn.json(result.isNew ? 201 : 200, book);
    }, function (err) {
      return conn.json(500, {error: err.message});
    });
  });
});

app.get('/author', function (conn) {
  return conn.getParams().then(function (params) {
    var deferred = Q.defer();
    db.author.findByGenre(params.genre, deferred.makeNodeResolver());
    return deferred.promise.then(function (authors) {
      return conn.json(200, authors);
    }, function (err) {
      return conn.json(500, {error: err.message});
    });
  });
});

var library = swig.compileFile('./library.swig');
var err500 = swig.compileFile('./err500.swig');

app.get('/library', function (conn) {
  var deferred = Q.defer();
  db.book.all(deferred.makeNodeResolver());
  return deferred.promise.then(function (books) {
    return conn.html(200, library({books: books}));
  }, function (err) {
    return conn.html(500, err500({err: err.message}));
  });
});

app.get('/library.xml', function (conn) {
  var deferred = Q.defer();
  db.book.all(deferred.makeNodeResolver());
  conn.response.setHeader('Content-Type', 'application/xml');
  return deferred.promise.then(function (books) {
    return conn.send(200, xmlify('books', books));
  }, function (err) {
    return conn.send(500, xmlify('err', err.message));
  });
});

app.get('/', function (conn) {
  return conn.redirect('/library');
});

// serve the stack on a port
mach.serve(app, 8080);
// or mach.serve(app, {port: 8080});