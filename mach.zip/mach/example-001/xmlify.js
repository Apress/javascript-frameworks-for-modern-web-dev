'use strict';

function toSingular(s) {
  if (s.toLowerCase().substr(-2) === 'es') {
    return s.substr(0, s.length - 2);
  }
  if (s.toLowerCase().substr(-1) === 's') {
    return s.substr(0, s.length -1);
  }
  return s;
}

var OPEN_TAG = '<$1';
var MID_TAG = '>$1<';
var CLOSE_TAG = '/$1>';

function isNot(value) {
  return value === null ||
    (typeof value === 'undefined');
}

var PRIMITIVES = ['string', 'number', 'boolean'];

function isPrimitive(value) {
  return PRIMITIVES.indexOf(typeof value) > -1;
}

function isArray(value) {
  return Array.isArray(value);
}

function isHash(value) {
  return (typeof value === 'object') &&
      value.toString() === '[object Object]';
}

function xmlify(name, value) {
  var open = OPEN_TAG.replace('$1', name);
  var close = CLOSE_TAG.replace('$1', name);
  var attrs = [];
  var children = [];

  if (isNot(value)) {
    return open + ' />';
  }

  if (isPrimitive(value)) {
    return [
      open,
      MID_TAG.replace('$1', value),
      open
    ].join('');
  }

  if (isHash(value)) {
    for (var key in value) {
      if (!value.hasOwnProperty(key)) continue;
      var subvalue = value[key];
      if (isNot(subvalue)) continue;
      if (isPrimitive(subvalue)) {
        attrs.push('$1="$2"'.replace('$1', key).replace('$2', subvalue));
      }
      if (isHash(subvalue) || isArray(subvalue)) {
        children.push(xmlify(key, subvalue));
      }
    }
    open = open + (attrs.length ? ' ' + attrs.join(' ') : '');
    // tag with only attributes, no children
    if (!children.length) {
      return open + ' />';
    }
    // tag with attributes and children
    return [
      open,
      MID_TAG.replace('$1', children.join('')),
      close
    ].join('');
  }

  if (isArray(value)) {
    value.forEach(function (subvalue) {
      children.push(xmlify(toSingular(name), subvalue));
    });
    // tag with only attributes, no children
    if (!children.length) {
      return open + ' />';
    }
    // tag with attributes and children
    return [
      open,
      MID_TAG.replace('$1', children.join('')),
      close
    ].join('');
  }

  // at this point we've no idea what it is, just
  // stringify and move on
  return [
    open,
    MID_TAG.replace('$1', value.toString()),
    close
  ].join('');
}

module.exports = xmlify;