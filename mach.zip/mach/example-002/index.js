'use strict';
var mach = require('mach');
var fs = require('fs');
var path = require('path');

// create a stack
var app = mach.stack();

// add some middleware
app.use(mach.logger);

// Mach.contentType + Mach.charset
app.use(mach.charset, 'utf-8');
app.use(mach.contentType, 'application/xml');

var insultsFilePath = path.join(__dirname, 'insults.xml');
app.get('/insults', function (conn) {
  conn.send(200, fs.createReadStream(insultsFilePath));
});

mach.serve(app, 8080);