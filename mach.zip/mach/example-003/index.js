'use strict';
var mach = require('mach');
var path = require('path');

// create a stack
var app = mach.stack();

// add some middleware
app.use(mach.logger);

// Mach.file
var publicDir = path.join(__dirname, 'public');
app.use(mach.file, {
  root: publicDir,
  // index: true || ['index.html', 'index.htm', ...]
  autoIndex: true
});

mach.serve(app, 8080);