(function (D) {
  'use strict';

  function random(min, max) {
    return Math.floor(Math.random() * (max - min)) + min;
  }

  var memes = D.querySelectorAll('.meme'),
    minIndex = 0,
    maxIndex = memes.length - 1;

  setInterval(function () {
    var memeIndex = minIndex;
    while (memeIndex <= maxIndex) {
      memes[memeIndex].className = 'meme';
      memeIndex += 1;
    }
    var randomIndex = random(minIndex, maxIndex);
    memes[randomIndex].className = 'meme bordered';
  }, 2000);

}(window.document));