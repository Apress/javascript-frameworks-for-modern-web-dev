'use strict';
var heroes = require('./heroes');

function upsert(collection, item, predicate, cb) {
  var newID = (collection.length + 1);
  // insert
  if (arguments.length === 3) {
    cb = predicate;
    item.id = newID;
    collection.push(item);
    cb(null, newID, true);
  }
  process.nextTick(function () {
    // update
    var index = 0, len = collection.length;
    while (index < len) {
      var oldItem = collection[index];
      if (predicate(oldItem)) {
        collection[index] = item;
        return cb(null, item.id, false);
      }
      index += 1;
    }
    // item not found, insert
    item.id = newID;
    collection.push(item);
    cb(null, newID, true);
  });
}

module.exports = {
  hero: {
    save: function (hero, cb) {
      upsert(heroes, hero, function willUpdate (oldHero) {
        return hero.hasOwnProperty('id') &&
          oldHero.id === hero.id;
      }, function (err, id, isNew) {
        if (err) return cb(err);
        cb(null, {id: id, isNew: isNew});
      });
    },

    page: function (skip, take, cb) {
      process.nextTick(function () {
        var result = (take > 0) ?
          heroes.slice(skip, skip + take) :
          [];
        cb(null, result);
      });
    }
  }
};
