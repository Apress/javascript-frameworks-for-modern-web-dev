'use strict';
module.exports = [
  {
    id: 1,
    name: 'Dynaheir',
    race: 'Human',
    'class': 'Invoker',
    alignment: 'Lawful Good'
  },
  {
    id: 2,
    name: 'Imoen',
    race: 'Human',
    'class': 'Thief',
    alignment: 'Neutral Good'
  },
  {
    id: 3,
    name: 'Khalid',
    race: 'Half-Elf',
    'class': 'Fighter',
    alignment: 'Neutral Good'
  },
  {
    id: 4,
    name: 'Xan',
    race: 'Elf',
    'class': 'Enchanter',
    alignment: 'Lawful Neutral'
  },
  {
    id: 5,
    name: 'Edwin',
    race: 'Human',
    'class': 'Conjurer',
    alignment: 'Lawful Evil'
  }
];