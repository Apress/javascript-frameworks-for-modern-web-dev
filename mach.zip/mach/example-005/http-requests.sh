#!/usr/bin/env bash

# post a new hero
#curl -X POST http://localhost:8080/hero \
#    -H "Content-Type: application/x-www-form-urlencoded" \
#    -d "name=Minsc&race=Human&class=Ranger&subclass=Berserker&alignment=Neutral%20Good&companion=Boo"

# page heroes
#curl -X GET http://localhost:8080/hero?skip=0\&take=3
#curl -X GET http://localhost:8080/hero?skip=3\&take=3