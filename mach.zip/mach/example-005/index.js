'use strict';
var mach = require('mach');
var path = require('path');
var Q = require('q');
var db = require('./db');

// create a stack
var app = mach.stack();

// add some middleware
app.use(mach.logger);

// Mach.params
app.use(mach.params);

app.post('/hero', function (conn) {
  var deferred = Q.defer();
  db.hero.save(conn.params, deferred.makeNodeResolver());
  return deferred.promise.then(function (result) {
    return conn.json(201, result);
  }, function (err) {
    return conn.json(500, {err: err.message});
  });
});

app.get('/hero'/*?skip=#&take=#*/, function (conn) {
  var skip = Number(conn.params.skip || 0),
    take = Number(conn.params.take || 0);
  var deferred = Q.defer();
  db.hero.page(skip, take, deferred.makeNodeResolver());
  return deferred.promise.then(function (heroes) {
    return conn.json(200, heroes);
  }, function (err) {
    return conn.json(500, {err: err.message});
  })
});

mach.serve(app, 8080);