'use strict';
var Q = require('q');

var users = [
  {
    id: 1,
    username: 'dvader',
    password: 's1th4l!f3'
  }
];

module.exports = {
  user: {
    byCredential: function (username, password) {
      return Q().then(function () {
        var user;
        for (var index in users) {
          if (!users.hasOwnProperty(index)) {
            continue;
          }
          user = users[index];
          if (user.username === username &&
            user.password === password) {
            return user;
          }
        }
        throw new Error('invalid credentials');
      });
    }
  }
};