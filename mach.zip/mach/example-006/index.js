'use strict';
var mach = require('mach');
var fs = require('fs');
var path = require('path');
var Q = require('q');
var db = require('./db');

// create a stack
var app = mach.stack();

// add some middleware
app.use(mach.logger);

// Mach.basicAuth
app.use(mach.basicAuth, function (username, password) {
  return db.user.byCredential(username, password).then(function (user) {
    return user.username;
  }, function (/*err*/) {
    return false;
  });
});

var indexPath = path.join(__dirname, 'index.html');

app.get('/', function (conn) {
  return conn.html(200, fs.createReadStream(indexPath));
});

mach.serve(app, 8080);