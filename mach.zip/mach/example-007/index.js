'use strict';
var mach = require('mach');
var path = require('path');
var Q = require('q');
var swig = require('swig');

// create a stack
var app = mach.stack();

// add some middleware
app.use(mach.logger);

var sessionSecret = 'c94ac0cf8f3b89bf9987d1901863f562592b477b450c26751a5d6964cbdce9eb085c013d5bd48c7b4ea64a6300c2df97825b9c8b677c352a46d12b8cc5879554';

// Mach.session
app.use(mach.session, {
  secret: sessionSecret
});

var quizView = swig.compileFile('./quiz.swig');

app.get('/', function (conn) {
  return conn.html(200, quizView(conn.session));
});

var successView = swig.compileFile('./success.swig');
var errView = swig.compileFile('./err.swig');

app.post('/questions/three', function (conn) {
  return conn.getParams().then(function (params) {
    conn.session.name = params.name;
    conn.session.quest = params.quest;
    conn.session.colour = params.colour;
    return conn.html(201, successView());
  }, function (err) {
    return conn.html(500, errView(err));
  });
});

mach.serve(app, 8080);