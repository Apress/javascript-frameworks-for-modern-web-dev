'use strict';
var mach = require('mach');
var path = require('path');
var swig = require('swig');

// create a stack
var app = mach.stack();

// add some middleware
app.use(mach.logger);

var RedisStore = require('mach/lib/middleware/session/RedisStore');

// Mach.session
app.use(mach.session, {
 store: new RedisStore({url: 'redis://127.0.0.1:6379'})
});

var quizView = swig.compileFile('./quiz.swig');

app.get('/', function (conn) {
  return conn.html(200, quizView(conn.session));
});

var successView = swig.compileFile('./success.swig');
var errView = swig.compileFile('./err.swig');

app.post('/questions/three', function (conn) {
  return conn.getParams().then(function (params) {
    conn.session.name = params.name;
    conn.session.quest = params.quest;
    conn.session.colour = params.colour;
    return conn.html(201, successView());
  }, function (err) {
    return conn.html(500, errView(err));
  });
});

mach.serve(app, 8080);