'use strict';

function Author(name) {
  this.id = 0;
  this.name = name || '';
  this.website = '';
  this.genres = [];
  this.lastModified = '';
}

Author.fromParams = function (params) {
  var author = new Author(params.name);
  author.id = Number(params.id || 0);
  author.website = params.website || '';
  author.genres = (params.genres || '').split(',');
  return author;
};

module.exports = Author;