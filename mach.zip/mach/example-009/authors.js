'use strict';

module.exports = [
  {
    id: 1,
    name: 'Hugh Howey',
    website: 'http://www.hughhowey.com',
    genres: ['Science Fiction', 'Fantasy', 'Short Stories'],
    lastModified: '2015-04-06T00:26:30.744Z'
  },
  {
    id: 2,
    name: 'Frank Herbert',
    website: 'http://www.dunenovels.com/',
    genres: ['Science Fiction', 'Fantasy'],
    lastModified: '2015-04-06T00:26:30.744Z'
  },
  {
    id: 3,
    name: 'Terry Goodkind',
    website: 'http://www.terrygoodkind.com/',
    genres: ['Science Fiction', 'Fantasy'],
    lastModified: '2015-04-06T00:26:30.744Z'
  },
  {
    id: 4,
    name: 'Andrzej Sapkowski',
    website: 'http://www.sapkowski.pl/',
    genres: ['Science Fiction', 'Fantasy', 'Historical Fiction'],
    lastModified: '2015-04-06T00:26:30.744Z'
  },
  {
    id: 5,
    name: 'Patrick Rothfuss',
    website: 'http://www.patrickrothfuss.com/content/index.asp',
    genres: ['Science Fiction', 'Fantasy', 'Young Adult'],
    lastModified: '2015-04-06T00:26:30.744Z'
  },
  {
    id: 6,
    name: 'Dan Simmons',
    website: 'http://www.dansimmons.com/',
    genres: ['Science Fiction', 'Fantasy', 'Literature', 'Horror'],
    lastModified: '2015-04-06T00:26:30.744Z'
  },
  {
    id: 7,
    name: 'J. Gregory Keyes',
    website: 'http://www.gregkeyes.com/',
    genres: ['Science Fiction', 'Fantasy'],
    lastModified: '2015-04-06T00:26:30.744Z'
  },
  {
    id: 8,
    name: 'Joe Abercrombie',
    website: 'http://www.joeabercrombie.com/',
    genres: ['Science Fiction', 'Fantasy'],
    lastModified: '2015-04-06T00:26:30.744Z'
  }
];