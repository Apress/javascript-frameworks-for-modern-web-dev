'use strict';
var books = require('./books');
var authors = require('./authors');

function findOne(collection, predicate, cb) {
  process.nextTick(function () {
    var index = 0, len = collection.length;
    while (index < len) {
      var item = collection[index];
      if (predicate(item)) {
        return cb(null, item);
      }
      index += 1;
    }
    cb(null, null);
  });
}

function upsert(collection, item, predicate, cb) {
  var newID = (collection.length + 1);
  // insert
  if (arguments.length === 3) {
    cb = predicate;
    item.id = newID;
    collection.push(item);
    cb(null, newID, true);
  }
  process.nextTick(function () {
    // update
    var index = 0, len = collection.length;
    while (index < len) {
      var oldItem = collection[index];
      if (predicate(oldItem)) {
        collection[index] = item;
        return cb(null, item.id, false);
      }
      index += 1;
    }
    // item not found, insert
    item.id = newID;
    collection.push(item);
    cb(null, newID, true);
  });
}

module.exports = {
  book: {
    findByID: function (id, cb) {
      findOne(books, function (book) {
        return book.id === id;
      }, cb);
    },

    save: function (book, cb) {
      upsert(books, book, function willUpdate (oldBook) {
        return book.hasOwnProperty('id') &&
          oldBook.id === book.id;
      }, function (err, id, isNew) {
        if (err) return cb(err);
        cb(null, {id: id, isNew: isNew});
      });
    }
  },

  author: {
    findByID: function (id, cb) {
      findOne(authors, function (author) {
        return author.id === id;
      }, cb);
    },

    save: function (author, cb) {
      upsert(authors, author, function willUpdate (oldAuthor) {
        return author.hasOwnProperty('id') &&
          oldAuthor.id === author.id;
      }, function (err, id, isNew) {
        if (err) return cb(err);
        author.lastModified = (new Date()).toISOString();
        cb(null, {id: id, isNew: isNew});
      });
    }
  }
};
