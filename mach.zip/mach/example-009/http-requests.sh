#!/usr/bin/env bash

# fetch a specific book and its ETag response header
#curl -v -X GET http://localhost:8080/book/1

# conditionally fetch a specific book if its ETag has been updated
#curl -v -H "If-None-Match: cf0fdc372106caa588f794467a17e893" -X GET http://localhost:8080/book/1

# update a book to see its ETag change
#curl -X PUT http://localhost:8080/book/1 \
#    -H "Content-Type: application/x-www-form-urlencoded" \
#    -d "title=God%20Emperor%20of%20Dune&author=Franklin%20Patrick%20Herbert&publisher=Victor%20Gollancz&publicationDate=2003-03-13T06:00:00.000Z&seriesTitle=Dune%20Chronicles&seriesPosition=4"


# fetch a specific author and its Last-Modified header
#curl -v -X GET http://localhost:8080/author/1

# conditionally fetch a specific author if if has been modified since a specific timestamp
#curl -v -H "If-Modified-Since: 2015-04-06T00:26:30.744Z" -X GET http://localhost:8080/author/1

# update an author to see its Last-Modified date change
#curl -X PUT http://localhost:8080/author/1 \
#    -H "Content-Type: application/x-www-form-urlencoded" \
#    -d "name=Hugh%20C.%20Howey&website=http%3A%2F%2Fwww.hughhowey.com&genres=Science%20Fiction%2CFantasy%2CShort%20Stories"