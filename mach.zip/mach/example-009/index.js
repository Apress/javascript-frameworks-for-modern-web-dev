'use strict';
var jsonHash = require('./json-hash');
var mach = require('mach');
var Q = require('q');
var db = require('./db');
var Book = require('./book');
var Author = require('./author');

// create a stack
var app = mach.stack();

// add some middleware
app.use(mach.logger);
app.use(mach.params);

// Mach.modified
app.use(mach.modified);

app.get('/book/:id', function (conn) {
  var id = Number(conn.params.id);
  var deferred = Q.defer();
  db.book.findByID(id, deferred.makeNodeResolver());
  return deferred.promise.then(function (book) {
    if (!book) {
      return conn.json(404);
    }
    conn.response.setHeader('ETag', jsonHash(book));
    return conn.json(200, book);
  }, function (err) {
    return conn.json(500, {error: err.message});
  });
});

app.put('/book/:id', function (conn) {
    var book = Book.fromParams(conn.params);
    var deferred = Q.defer();
    db.book.save(book, deferred.makeNodeResolver());
    return deferred.promise.then(function (result) {
      conn.response.setHeader('ETag', jsonHash(book));
      return conn.json(result.isNew ? 201 : 200, book);
    }, function (err) {
      return conn.json(500, {error: err.message});
    });
});

app.get('/author/:id', function (conn) {
  var id = Number(conn.params.id);
  var deferred = Q.defer();
  db.author.findByID(id, deferred.makeNodeResolver());
  return deferred.promise.then(function (author) {
    if (!author) {
      return conn.json(404);
    }
    conn.response.setHeader('Last-Modified', author.lastModified);
    return conn.json(200, author);
  }, function (err) {
    return conn.json(500, {error: err.message});
  });
});

app.put('/author/:id', function (conn) {
  var author = Author.fromParams(conn.params);
  var deferred = Q.defer();
  db.author.save(author, deferred.makeNodeResolver());
  return deferred.promise.then(function (result) {
    conn.response.setHeader('Last-Modified', author.lastModified);
    return conn.json(result.isNew ? 201 : 200, author);
  }, function (err) {
    return conn.json(500, {error: err.message});
  });
});

// serve the stack on a port
mach.serve(app, 8080);