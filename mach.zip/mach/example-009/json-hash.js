'use strict';
var crypto = require('crypto');
var stableStringify = require('json-stable-stringify');

module.exports = function hash(json) {
  var shasum = crypto.createHash('md5');
  shasum.update(stableStringify(json));
  return shasum.digest('hex');
};