'use strict';
var posts = require('./posts');

function findOne(collection, predicate, cb) {
  process.nextTick(function () {
    var index = 0, len = collection.length;
    while (index < len) {
      var item = collection[index];
      if (predicate(item)) {
        return cb(null, item);
      }
      index += 1;
    }
    cb(null, null);
  });
}

module.exports = {
  posts: {
    find: function (year, month, day, slug, cb) {
      findOne(posts, function (post) {
        return post.year === year &&
          post.month === month &&
          post.day === day &&
          post.slug === slug;
      }, cb);
    },

    all: function (cb) {
      process.nextTick(function () {
        return cb(null, posts);
      });
    }
  }
};
