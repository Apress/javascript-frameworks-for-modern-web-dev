'use strict';
var mach = require('mach');
var path = require('path');
var Q = require('q');
var swig = require('swig');
var db = require('./db');

// create a stack
var app = mach.stack();

// add some middleware
app.use(mach.logger);
app.use(mach.params);

var blogView = swig.compileFile(path.join(__dirname, 'blog.swig'));
var errView = swig.compileFile(path.join(__dirname, 'err.swig'));

app.use(
  mach.rewrite,
  // converts: /index.php/blog/2015-04-02/bacon-ipsum-dolor-amet
  new RegExp('\/index\.php\/blog\/([\\d]{4})-([\\d]{2})-([\\d]{2})\/([^\/]+)'),
  // into: /blog/2015/04/02/bacon-ipsum-dolor-amet
  '/blog/$1/$2/$3/$4'
);

// :year=$1, :month=$2, :day=$3, :slug=$4
app.get('/blog/:year/:month/:day/:slug', function (conn) {
  var year = Number(conn.params.year || 0),
    month = Number(conn.params.month || 0),
    day = Number(conn.params.day || 0),
    slug = conn.params.slug || '';
  var deferred = Q.defer();
  db.posts.find(year, month, day, slug, deferred.makeNodeResolver());
  return deferred.promise.then(function (post) {
    if (post) {
      return conn.html(200, blogView({posts: [post]}));
    }
    return conn.html(404, errView({message: 'I haven\t written that yet.'}))
  }, function (err) {
    return conn.html(500, errView(err));
  });
});

app.use(
  mach.rewrite,
  '/index.php/blog',
  '/blog'
);

app.get('/blog', function (conn) {
  var deferred = Q.defer();
  db.posts.all(deferred.makeNodeResolver());
  return deferred.promise.then(function (posts) {
    return conn.html(200, blogView({posts: posts}));
  }, function (err) {
    return conn.html(500, errView(err));
  });
});

mach.serve(app, 8080);