'use strict';

module.exports = [
  {
    id: 1,
    year: 2015,
    month: 4,
    day: 2,
    slug: 'bacon-ipsum-dolor-amet',
    title: 'Bacon ipsum dolor amet',
    content: 'Bacon ipsum dolor amet tri-tip ham hock venison spare ribs chicken. Shoulder jerky hamburger pork chop andouille kevin spare ribs chuck corned beef jowl pig filet mignon. Doner tri-tip corned beef beef, pig chicken ham t-bone bacon pork chop tongue biltong porchetta meatball. Corned beef turkey venison cow turducken sausage pork chop fatback prosciutto ribeye jowl cupim. Ball tip ham salami filet mignon frankfurter turkey prosciutto cupim venison boudin alcatra rump short ribs capicola bresaola. Biltong salami flank short loin, cow short ribs brisket tongue.'
  },
  {
    id: 2,
    year: 2015,
    month: 4,
    day: 3,
    slug: 'filet-mignon-tail-pig-jerky',
    title: 'Filet mignon tail pig jerky',
    content: 'Filet mignon tail pig jerky hamburger. Salami ham tenderloin, hamburger turducken chicken bresaola. Jowl filet mignon ball tip sirloin tongue strip steak. Turkey tenderloin doner tongue salami kielbasa pastrami ground round. Venison meatball corned beef porchetta leberkas beef alcatra pork loin jerky tri-tip chicken meatloaf cupim.'
  },
  {
    id: 3,
    year: 2015,
    month: 4,
    day: 5,
    slug: 'pastrami-capicola-landjaeger-picanha',
    title: 'Pastrami capicola landjaeger picanha',
    content: 'Pastrami capicola landjaeger picanha kevin ribeye leberkas pancetta pork chop cow tenderloin shoulder meatball. Venison shoulder porchetta, pancetta cupim pork chop alcatra chuck. Pork leberkas shank flank beef venison, salami capicola fatback. Turducken frankfurter cow jerky tail spare ribs sausage pork loin shank tenderloin strip steak rump fatback.'
  }
];