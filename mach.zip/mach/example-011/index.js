'use strict';
var mach = require('mach');
var path = require('path');
var fs = require('fs');

// create a stack
var app = mach.stack();

// add some middleware
app.use(mach.logger);
app.use(mach.params);
app.use(mach.file, path.join(__dirname, 'public'));

/*
 * /etc/hosts file entries
 * 127.0.0.1 house-atreides.org
 * 127.0.0.1 house-harkonnen.org
 */

var atreidesApp = mach.stack();

atreidesApp.get('/about', function (conn) {
  var pagePath = path.join(__dirname, 'atreides.html');
  return conn.html(200, fs.createReadStream(pagePath));
});

var harkonnenApp = mach.stack();

harkonnenApp.get('/about', function (conn) {
  var pagePath = path.join(__dirname, 'harkonnen.html');
  return conn.html(200, fs.createReadStream(pagePath));
});

app.use(mach.mapper, {
  'http://house-atreides.org/': atreidesApp,
  'http://house-harkonnen.org/': harkonnenApp
});

app.get('/about', function (conn) {
  var pagePath = path.join(__dirname, 'about.html');
  return conn.html(200, fs.createReadStream(pagePath));
});

app.get('/', function (conn) {
  return conn.redirect('/about');
});

mach.serve(app, 8080);