'use strict';

// layer 1
function apiVersion(app, options) {
  // layer 2
  return function (conn) {
    // layer 3
    return conn.call(app).then(function () {
      conn.response.headers['X-API-Version'] = options.version;
    });
  };
}

module.exports = apiVersion;