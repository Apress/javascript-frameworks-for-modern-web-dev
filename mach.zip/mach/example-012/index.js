'use strict';
var mach = require('mach');
var apiVersion = require('./api-version');

// create a stack
var app = mach.stack();

// add some middleware
app.use(mach.logger);

// custom middleware
app.use(apiVersion, {version: '1.2'});

// out-of-the-box middleware
app.use(mach.gzip);

app.get('/numbers', function (conn) {
  return conn.json(200, [4, 8, 15, 16, 23, 42]);
});

mach.serve(app, 8080);