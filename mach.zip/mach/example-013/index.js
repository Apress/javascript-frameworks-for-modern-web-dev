'use strict';
var mach = require('mach');
var path = require('path');
var semver = require('semver');

// create a stack
var app = mach.stack();

// add some middleware
app.use(mach.logger);
app.use(mach.file, {
  root: path.join(__dirname, 'public'),
  index: true
});

app.get('/releases', function (conn) {
  function addUserAgent(conn) {
    conn.request.setHeader('User-Agent', 'nicholascloud/mach');
  }
  return mach.get('https://api.github.com/repos/mjackson/mach/tags', addUserAgent).then(function (conn) {
    var tags = [];
    JSON.parse(conn.responseText).forEach(function (tagData) {
      tags.push(tagData.name);
    });
    return tags.sort(semver.rcompare);
  }).then(function (tags) {
    return conn.json(200, tags);
  }, function (err) {
    return conn.json(500, {err: err.message});
  });
});

mach.serve(app, 8080);