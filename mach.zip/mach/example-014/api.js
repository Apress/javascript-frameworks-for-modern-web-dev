'use strict';
var mach = require('mach');
var votes = require('./votes');

var app = mach.stack();
app.use(mach.logger);
app.use(mach.params);

app.get('/api/vote', function (conn) {
  var tallies = {};
  var voteCount = votes.length;
  votes.forEach(function (vote) {
    var tally = tallies[vote] || {
      count: 0,
      percent: 0.0
    };
    tally.count += 1;
    tally.percent = Number((tally.count / voteCount * 100).toFixed(2));
    tallies[vote] = tally;
    return tallies;
  });
  return conn.json(200, tallies);
});

app.post('/api/vote', function (conn) {
  console.log(conn.params);
  var vote = conn.params.vote || '';
  if (!vote) {
    return conn.json(400, {err: 'Empty vote submitted.'});
  }
  votes.push(vote);
  return conn.json(201, {count: 1});
});

mach.serve(app, 8090);
