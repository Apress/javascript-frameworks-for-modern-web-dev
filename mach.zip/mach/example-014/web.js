'use strict';
var mach = require('mach');
var path = require('path');
var fs = require('fs');

var app = mach.stack();
app.use(mach.logger);
app.use(mach.file, path.join(__dirname, 'public'));

app.get('/', function (conn) {
  var pagePath = path.join(__dirname, 'index.html');
  return conn.html(200, fs.createReadStream(pagePath));
});

var apiProxy = mach.createProxy('http://localhost:8090');

app.use(mach.proxy, apiProxy);

mach.serve(app, 8080);