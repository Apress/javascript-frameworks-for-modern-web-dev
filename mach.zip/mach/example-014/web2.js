'use strict';
var mach = require('mach');
var path = require('path');
var fs = require('fs');

var app = mach.stack();
app.use(mach.logger);
app.use(mach.file, path.join(__dirname, 'public'));

var apiProxy = mach.createProxy('http://localhost:8090');

app.use(function (app) {
  return function (conn) {
    if (conn.location.pathname.indexOf('/api') !== 0) {
      // not an API method, call the app stack normally
      return conn.call(app);
    }
    // API method, call the proxy app stack
    return conn.call(apiProxy);
  };
});

app.get('/', function (conn) {
  var pagePath = path.join(__dirname, 'index.html');
  return conn.html(200, fs.createReadStream(pagePath));
});

mach.serve(app, 8080);