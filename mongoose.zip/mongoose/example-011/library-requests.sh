#!/usr/bin/env bash

# fetching a library (with populated albums) by ID
# curl -s -X GET http://localhost:8080/library/54ed249312c06b3726d3abcd