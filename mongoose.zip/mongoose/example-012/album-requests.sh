#!/usr/bin/env bash

# finding an album by track
# curl -X GET http://localhost:8080/album?track=The%20Looking%20Glass

# finding album "specials"
# curl -X GET http://localhost:8080/album/recommended