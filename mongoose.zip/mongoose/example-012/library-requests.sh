#!/usr/bin/env bash

# get library by owner (regex)
# curl -X GET http://localhost:8080/library?owner=cloud
