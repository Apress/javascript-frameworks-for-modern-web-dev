'use strict';
var fs = require('fs');
var path = require('path');
var playerStats = require('./player-stats');

function getPlayerStats(gamesFilePath, playerID, cb) {
  // fs.readFile() is asynchronous
  fs.readFile(gamesFilePath, {encoding: 'utf8'}, function (err, content) {
    if (err) {
      return cb(err);
    }

    var games = JSON.parse(content);
    var playerGames = games.filter(function (game) {
      return game.player === playerID;
    });

    // playerStats.calcBest() is asynchronous
    playerStats.calcBest(playerGames, function (err, bestStats) {
      if (err) {
        return cb(err);
      }
      // playerStats.calcAvg() is asynchronous
      playerStats.calcAvg(playerGames, function (err, avgStats) {
        if (err) {
          return cb(err);
        }
        cb(null, {best: bestStats, avg: avgStats});
      });
    });
  });
}

var gamesFilePath = path.join(__dirname, 'games.json');
getPlayerStats(gamesFilePath, 42, function (err, stats) {
  if (err) {
    console.error(err);
    return process.exit(1);
  }
  console.log('best:', stats.best);
  console.log('avg: ', stats.avg)
});