'use strict';
var fs = require('fs');
var path = require('path');
var playerStats = require('./player-stats');

try {
  var gamesFilePath = path.join(__dirname, 'games.json');
  // fs.readFileSync() is synchronous
  var content = fs.readFileSync(gamesFilePath, {encoding: 'utf8'});
  var games = JSON.parse(content);
  var playerGames = games.filter(function (game) {
    return game.player === 42;
  });
  // playerStats.calcBestSync() is synchronous
  console.log('best:', playerStats.calcBestSync(playerGames));
  // playerStats.calcAvgSync() is synchronous
  console.log('avg :', playerStats.calcAvgSync(playerGames));
} catch (e) {
  console.error(e);
  process.exit(1);
}