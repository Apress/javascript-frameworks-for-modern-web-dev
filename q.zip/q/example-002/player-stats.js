'use strict';
module.exports = {
  calcBestSync: function (games) {
    var stats = {
      totalGames: games.length,
      bestScore: 0,
      gamesScoredBest: 0
    };

    if (games.length === 0) {
      throw new Error('no games')
    }

    games.reduce(function (previousBest, nextGame) {
      // same best score
      if (stats.bestScore === nextGame.won) {
        stats.gamesScoredBest += 1;
      }
      // a new best score
      if (stats.bestScore < nextGame.won) {
        stats.bestScore = nextGame.won;
        stats.gamesScoredBest = 1;
      }
      return Math.max(previousBest, nextGame.won);
    }, 0);

    return stats;
  },

  calcAvgSync: function (games) {
    var stats = {
      totalRounds: 0,
      avgRoundsWon: 0,
      avgRoundsLost: 0
    };

    if (games.length === 0) {
      throw new Error('no games');
    }

    var wins = 0, losses = 0;
    games.forEach(function (game) {
      if (game.rounds === 0) return;
      stats.totalRounds += game.rounds;
      wins += game.won;
      losses += game.lost;
    });

    stats.avgRoundsWon = (wins / stats.totalRounds * 100)
      .toFixed(2) + '%';
    stats.avgRoundsLost = (losses / stats.totalRounds * 100)
      .toFixed(2) + '%';

    return stats;
  }
};