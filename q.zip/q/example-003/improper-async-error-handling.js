'use strict';
var fs = require('fs');
var path = require('path');

function readJSONFile(filePath, cb) {
  fs.readFile(filePath, function (err, buffer) {
    try {
      var json = JSON.parse(buffer.toString());
      cb(null, json);
    } catch (e) {
      console.log('where did this error come from?', e.message);
      cb(e);
    }
  });
}

var gamesFilePath = path.join(__dirname, 'games.json');
readJSONFile(gamesFilePath, function (err, json) {
  if (err) {
    return console.error('parsing json did not succeed :(');
  }
  console.log('parsing json was successful :)');
  throw new Error('should never happen, right?');
});