'use strict';
var fs = require('fs');
var path = require('path');
var playerStats = require('./player-stats');
var Q = require('q');

function getPlayerStats(gamesFilePath, playerID, cb) {
  // load() returns a promise
  playerStats.load(gamesFilePath, playerID)
    .then(function (games) {
      // Q.all() returns a promise
      return Q.all([
        // calcBest() returns a promise
        playerStats.calcBest(games),
        // calcAvg() returns a promise
        playerStats.calcAvg(games)
      ]);
    })
    .done(function (allStats) {
      cb(null, {best: allStats[0], avg: allStats[1]});
    }, function (err) {
      cb(err);
    });
}

var gamesFilePath = path.join(__dirname, 'games.json');
getPlayerStats(gamesFilePath, 42, function (err, stats) {
  if (err) {
    console.error(err);
    return process.exit(1);
  }
  console.log('best:', stats.best);
  console.log('avg: ', stats.avg)
});