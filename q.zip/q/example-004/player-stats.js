'use strict';
var fs = require('fs');
var Q = require('q');

module.exports = {

  load: function (gamesFilePath, playerID) {
    var deferred = Q.defer();
    fs.readFile(gamesFilePath, {encoding: 'utf8'}, function (err, content) {
      var games = JSON.parse(content);
      var playerGames = games.filter(function (game) {
        return game.player === playerID;
      });
      deferred.resolve(playerGames);
    });
    return deferred.promise;
  },

  calcBest: function (games) {
    var stats = {
      totalGames: games.length,
      bestScore: 0,
      gamesScoredBest: 0
    };

    var deferred = Q.defer();

    process.nextTick(function () {
      if (games.length === 0) {
        deferred.reject(new Error('no games'));
        return;
      }

      games.reduce(function (previousBest, nextGame) {
        // same best score
        if (stats.bestScore === nextGame.won) {
          stats.gamesScoredBest += 1;
        }
        // a new best score
        if (stats.bestScore < nextGame.won) {
          stats.bestScore = nextGame.won;
          stats.gamesScoredBest = 1;
        }
        return Math.max(previousBest, nextGame.won);
      }, 0);

      deferred.resolve(stats);
    });

    return deferred.promise;
  },

  calcAvg: function (games) {
    var stats = {
      totalRounds: 0,
      avgRoundsWon: 0,
      avgRoundsLost: 0
    };

    var deferred = Q.defer();

    process.nextTick(function () {
      if (games.length === 0) {
        deferred.reject(new Error('no games'));
        return;
      }

      var wins = 0, losses = 0;
      games.forEach(function (game) {
        if (game.rounds === 0) return;
        stats.totalRounds += game.rounds;
        wins += game.won;
        losses += game.lost;
      });

      stats.avgRoundsWon = (wins / stats.totalRounds * 100)
        .toFixed(2) + '%';
      stats.avgRoundsLost = (losses / stats.totalRounds * 100)
        .toFixed(2) + '%';

      deferred.resolve(stats);
    });

    return deferred.promise;
  }
};