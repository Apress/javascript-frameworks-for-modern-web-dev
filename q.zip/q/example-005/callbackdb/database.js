'use strict';

module.exports = {
  customer: {
    // requires a callback
    find: function (criteria, cb) {
      cb(null, {
        id: criteria.id,
        name: 'Nicholas Cloud'
      });
    }
  }
};