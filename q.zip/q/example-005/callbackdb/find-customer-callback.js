var Q = require('q'),
  db = require('./database');

function loadCustomer(customerID) {
  var d = Q.defer();

  // db.customer.find() is asynchronous
  db.customer.find({id: customerID}, function (err, customer) {
    if (err) {
      return d.reject(err);
    }
    d.resolve(customer);
  });

  return d.promise;
}

loadCustomer(1001).then(function (customer) {
  console.log('found', customer.id, customer.name);
}, function (err) {
  console.error(err);
});