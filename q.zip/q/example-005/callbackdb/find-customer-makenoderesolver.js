var Q = require('q'),
  db = require('./database');

function loadCustomer(customerID) {
  var d = Q.defer();

  // db.customer.find() is asynchronous
  var deferredCallback = d.makeNodeResolver();
  db.customer.find({id: customerID}, deferredCallback);

  return d.promise;
}

loadCustomer(2001).then(function (customer) {
  console.log('found', customer.id, customer.name);
}, function (err) {
  console.error(err);
});