'use strict';
var Q = require('q');

module.exports = {
  customer: {
    // returns a promise; does not use callbacks
    find: function (criteria) {
      return Q({
        id: criteria.id,
        name: 'Nicholas Cloud'
      });
    }
  }
};