var Q = require('q'),
  db = require('./database');

function loadCustomer(customerID, cb) {

  // db.customer.find() returns a promise
  db.customer.find({id: customerID})
    .nodeify(cb);

  /* equivalent to:
   *
   * db.customer.find({id: customerID}).then(function (customer) {
   *   cb(null, customer);
   * }, function (err) {
   *   cb(err);
   * });
   */
}

loadCustomer(3001, function (err, customer) {
  if (err) {
    return console.err(err);
  }
  console.log('found', customer.id, customer.name);
});