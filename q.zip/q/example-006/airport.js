'use strict';

module.exports = {
  findFlights: function (fromAirport, toAirport, departingAt) {
    return ['Delta 1023', 'American 3051'];
  }
};