'use strict';

var Q = require('q'),
  airport = require('./airport'),
  reservation = require('./reservation');

function findAvailableSeats(departingFlights) {
  var d = Q.defer();
  process.nextTick(function () {
    var availableSeats = [];
    departingFlights.forEach(function (flight) {
      var openFlightSeats = reservation.findOpenSeats(flight);
      availableSeats = availableSeats.concat(openFlightSeats);
    });
    // resolve the deferred with an object value
    if (availableSeats.length) {
      d.resolve(availableSeats);
    } else {
      d.reject(new Error('sorry, no seats available'));
    }
  });
  return d.promise;
}

function lookupFlights(fromAirport, toAirport, departingAt) {
  var d = Q.defer();
  process.nextTick(function () {
    var departingFlights = airport.findFlights(
      fromAirport, toAirport, departingAt
    );
    // resolve the deferred with another promise
    d.resolve(findAvailableSeats(departingFlights));
  });
  return d.promise;
}

lookupFlights('STL', 'DFW', '2015-01-10').then(function (seats) {
  console.log('available seats:', seats);
}, function (err) {
  console.error('sorry:', err);
});