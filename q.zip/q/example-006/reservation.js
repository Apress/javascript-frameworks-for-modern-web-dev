'use strict';

function getRandomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

var seatLetters = ['A', 'B', 'C', 'D'];
var minRow = 1, maxRow = 30;

function makeSeat(flight) {
  return flight + ' seat ' +
    getRandomInt(minRow, maxRow) +
    seatLetters[getRandomInt(0, seatLetters.length - 1)];
}

module.exports = {
  findOpenSeats: function (flight) {
    var numAvailableSeats = getRandomInt(0, 7);
    var availableSeats = [];
    while (availableSeats.length < numAvailableSeats) {
      var seat = makeSeat(flight);
      while (availableSeats.indexOf(seat) >= 0) {
        seat = makeSeat();
      }
      availableSeats.push(seat);
    }
    return availableSeats;
  }
};