'use strict';
var db = require('./database');

function findPalindromeNames() {
  // db.customers.find() returns a promise
  return db.customer.find().then(function (customers) {
    // return a filtered array that will be forwarded
    // to the next resolution callback
    return customers.filter(function (customer) {
      // filter customers with palindrome names
      var name = customer.name.toLowerCase();
      var eman = name.split('').reverse().join('');
      return name === eman;
    }).map(function (customer) {
      // return only customer names
      return customer.name;
    });
  });
}

findPalindromeNames().then(function (names) {
  console.log(names);
});