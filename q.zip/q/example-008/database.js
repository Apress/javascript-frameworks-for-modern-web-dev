'use strict';
var Q = require('q');

var users = {
  '1001': {
    id: 1001,
    name: 'Nicholas Cloud',
    guesses: [
      'Miss Scarlett',
      'Colonel Mustard',
      'Mrs. White',
      'Reverend Green',
      'Mrs. Peacock'
    ]
  }
};

module.exports = {
  user: {
    find: function (criteria) {
      return Q(users[criteria.id]);
    }
  }
};