'use strict';
var db = require('./database');
var MaxGuessError = require('./max-guess-error');

var MAX_GUESSES = 5;

function submitGuess(userID, guess) {
  // db.user.find() returns a promise
  return db.user.find({id: userID}).then(function (user) {
    if (user.guesses.length === MAX_GUESSES) {
      throw new MaxGuessError(MAX_GUESSES);
    }
    // otherwise update the user...
  });
}

submitGuess(1001, 'Professor Plum').then(function () {
  // won't get called if there is an error
  console.log('guess submitted');
}, function (maxGuessError) {
  // oops, an error occurred!
  console.error('invalid guess');
  console.error(maxGuessError.toString());
});