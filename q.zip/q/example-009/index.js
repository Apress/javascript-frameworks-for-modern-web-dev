'use strict';
var db = require('./database');
var NotFoundError = require('./not-found-error');

function submitGuess(userID, guess) {
  // db.user.find() returns a promise
  return db.user.find({id: userID}).then(function (user) {
    /*
     * database generates an error so this promise
     * won't be resolved
     */
  }, function (err) {
    var notFoundError = new NotFoundError(userID);
    notFoundError.innerError = err;
    return notFoundError;
  });
}

submitGuess(1001, 'Colonel Mustard').then(function (value) {
  /*
   * oops, this promise was resolved, and
   * value === notFoundError!
   */
  console.log('guess submitted');
  console.log(value);
}, function (notFoundError) {
  /*
   * you expect this promise to get rejected...
   * but you are wrong
   */
  console.error('an error occurred');
  console.error(notFoundError);
});