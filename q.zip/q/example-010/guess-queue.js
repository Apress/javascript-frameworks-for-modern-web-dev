'use strict';
var Q = require('q');

module.exports = {
  enqueue: function (userID, guess) {
    return Q(1);
  }
};