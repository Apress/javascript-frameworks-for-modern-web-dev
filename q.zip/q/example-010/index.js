'use strict';
var db = require('./database');
var guessQueue = require('./guess-queue');

function submitGuess(userID, guess) {
  // db.user.find() returns a promise
  return db.user.find({id: userID}).then(function (user) {
    /*
     * database generates an error so this promise
     * won't be resolved
     */
  }, function (err) {
    console.error(err);
    /*
     * database is probably offline, queue for future
     * processing
     */
    return guessQueue.enqueue(userID, guess);
  });
}

submitGuess(1001, 'Miss Scarlett').then(function (value) {
  /*
   * guess is queued when the database connection
   * fails, so the error is suppressed
   */
  console.log('guess submitted');
}, function (notFoundError) {
  console.error('an error occurred');
  console.error(notFoundError);
});