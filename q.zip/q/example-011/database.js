'use strict';
var Q = require('q');

module.exports = {
  user: {
    find: function (criteria) {
      /*
       * simulate an error connecting to the database which will
       * cause the promise to be rejected
       */
      return Q().then(function () {
        throw new Error('unable to establish database connection');
      });
    }
  }
};