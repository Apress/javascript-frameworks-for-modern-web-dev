'use strict';
var db = require('./database');
var NotFoundError = require('./not-found-error');

function submitGuess(userID, guess) {
  // db.user.find() returns a promise
  return db.user.find({id: userID}).then(function (user) {
    /*
     * database generates an error so this promise
     * won't be resolved
     */
  }, function (err) {
    /*
     * error is *thrown*, not returned
     */
    var notFoundError = new NotFoundError(userID);
    notFoundError.innerError = err;
    throw notFoundError;
  });
}

submitGuess(1001, 'Mrs. Peacock').then(function (value) {
  /*
   * since error was thrown within the promise
   * the promise will not be resolved
   */
}, function (notFoundError) {
  /*
   * the promise is rejected, as expected!
   */
  console.error('an error occurred');
  console.error(notFoundError);
});