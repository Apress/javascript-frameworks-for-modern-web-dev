'use strict';

function NotFoundError(userID) {
  this.name = 'NotFoundError';
  this.message = userID + ' could not be found';
}

NotFoundError.prototype = Object.create(Error.prototype);
NotFoundError.prototype.constructor = NotFoundError;

module.exports = NotFoundError;