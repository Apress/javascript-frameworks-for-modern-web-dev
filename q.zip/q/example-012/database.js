'use strict';
var Q = require('q');

var users = {
  '1001': {
    id: 1001,
    name: 'Nicholas Cloud',
    guesses: []
  }
};

module.exports = {
  user: {
    find: function (criteria) {
      return Q(users[criteria.id]);
    },
    update: function (user) {
      return Q(users[user.id] = user);
    }
  }
};