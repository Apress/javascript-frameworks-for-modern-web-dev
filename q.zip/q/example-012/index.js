'use strict';
var db = require('./database');
var MaxGuessError = require('./max-guess-error');

var MAX_GUESSES = 5;

function submitGuess(userID, guess) {
  // db.user.find() returns a promise
  return db.user.find({id: userID}).then(function (user) {
    if (user.guesses.length === MAX_GUESSES) {
      throw new MaxGuessError(MAX_GUESSES);
    }
    // otherwise update the user
    user.guesses.push(guess);
    return db.user.update(user);
  });
}

submitGuess(1001, 'Professor Plum').then(function () {
  /*
   * should be called with the database has
   * finished updating the user
   */
  console.log('guess submitted');
}, function (maxGuessError) {
  console.error('invalid guess');
  console.error(maxGuessError.toString());
});