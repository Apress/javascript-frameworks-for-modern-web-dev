'use strict';

function MaxGuessError(limit) {
  this.name = 'MaxGuessError';
  this.message = 'guess limit met (' + limit + ')';
}

MaxGuessError.prototype = Object.create(Error.prototype);
MaxGuessError.prototype.constructor = MaxGuessError;

module.exports = MaxGuessError;