'use strict';
var Q = require('q');

Q('khan!').then(function (value) {
  console.log(value); //khan!
});