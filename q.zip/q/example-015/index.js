'use strict';
var Q = require('q');

function brokenPromise() {
  var d = Q.defer();
  process.nextTick(function () {
    console.log('scheduled first');
    d.notify('notifying');
    d.resolve('resolving');
    console.log('logging');
  });
  return d.promise;
}

var promise = brokenPromise();

process.nextTick(function () {
  console.log('scheduled second');
  promise.then(function (value) {
    console.log(value);
  }, null, function (progress) {
    console.log(progress);
  });
});