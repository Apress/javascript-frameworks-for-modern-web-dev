'use strict';
var Q = require('q');

module.exports = {
  get: function (url) {
    var deferred = Q.defer();
    process.nextTick(function () {
      deferred.reject({
        statusCode: 404
      });
    });
    return deferred.promise;
  }
};