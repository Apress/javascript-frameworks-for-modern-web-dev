'use strict';
var Q = require('q');
var api = require('./api');
var InvalidTeamError = require('./invalid-team-error');

function loadTeamRoster(teamID) {
  // api.get() returns a promise
  return api.get('/team/' + teamID + '/roster')
    .catch(function (err) {
      /*
       * throw a meaningful exception rather than
       * propagate an HTTP error
       */
      if (err.statusCode === 404) {
        throw new InvalidTeamError(teamID);
      }
    });
}

loadTeamRoster(123).then(function (roster) {
  console.log(roster);
}).catch(function (err) {
  console.error(err.message);
});