'use strict';

function InvalidTeamError(teamID) {
  this.name = 'InvalidTeamError';
  this.teamID = teamID;
  this.message = teamID + ' is not a valid team ID';
  this.code = 9000;
}

InvalidTeamError.prototype = Object.create(Error.prototype);
InvalidTeamError.prototype.constructor = InvalidTeamError;

module.exports = InvalidTeamError;