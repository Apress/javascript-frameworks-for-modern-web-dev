'use strict';
var Q = require('q');

var users = {
  '1001': {
    id: 1001,
    name: 'Nicholas Cloud',
    occupation: 'Software Developer'
  }
};

module.exports = {
  connect: function () {
    console.log('connecting...');
    return Q({
      isOpen: true,
      close: function () {
        console.log('closing connection');
        return Q();
      },
      user: {
        update: function (user) {
          console.log('updating user...');
          return Q(users[user.id] = user);
        }
      }
    });
  }
};