'use strict';
var Q = require('q');
var db = require('./database');

var user = {
  id: 1001,
  name: 'Nicholas Cloud',
  occupation: 'Code Monkey'
};

db.connect().then(function (conn) {
  return conn.user.update(user)
    .finally(function () {
      if (conn.isOpen) {
        conn.close();
      }
    });
});