'use strict';
var Q = require('q');

function crankyFunction() {
  var d = Q.defer();
  process.nextTick(function () {
    d.reject(new Error('get off my lawn!'));
  });
  return d.promise;
}

// no rejection callback to display the error
crankyFunction().then(function (value) {
  console.log('never resolved');
});