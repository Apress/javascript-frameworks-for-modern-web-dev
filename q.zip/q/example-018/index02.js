'use strict';
var Q = require('q');

function crankyFunction() {
  var d = Q.defer();
  process.nextTick(function () {
    d.reject(new Error('get off my lawn!'));
  });
  return d.promise;
}

/*
 * invoking done() will cause the thrown exception
 * to bubble up
 */
crankyFunction().then(function (value) {
  console.log('never resolved');
}).done(function (value) {
  console.log(value);
});