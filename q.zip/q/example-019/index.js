'use strict';
var Q = require('q');

function changePassword(cb) {
  process.nextTick(function () {
    console.log('changing password...');
    cb(null);
  });
}

function notifyUser(cb) {
  process.nextTick(function () {
    console.log('notifying user...');
    var randomFail = Date.now() % 2 === 0;
    cb(randomFail ? new Error('fail!') : null);
  });
}

function sendToNSA(cb) {
  process.nextTick(function () {
    console.log('sending to NSA...');
    cb(null);
  });
}

var steps = [changePassword, notifyUser, sendToNSA];
var lastPromise = Q();
steps.forEach(function (step) {
  lastPromise = lastPromise.then(function () {
    /*
     * denodeify and invoke each function step
     * to return a promise
     */
    return Q.denodeify(step)();
  });
});

lastPromise.done(function () {
  console.log('all done');
}, function (err) {
  console.error(err);
});