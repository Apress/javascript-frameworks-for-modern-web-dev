'use strict';
var Q = require('q');

function getUser(id, cb) {
  process.nextTick(function () {
    cb(null, {id: id, name: 'nick'});
  });
}

function getUSStates(cb) {
  process.nextTick(function () {
    cb(null, ['MO', 'IL' /*, etc.*/]);
  });
}

Q.all([
  Q.nfcall(getUser, 123),
  Q.nfcall(getUSStates)
]).spread(function (user, states) {
  console.log('user:', user);
  console.log('states:', states);
}, function (err) {
  console.error('ERR', err);
});