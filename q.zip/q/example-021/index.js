'use strict';
var Q = require('q');

function loadCandidates(cb) {
  console.log('loadCandidates', arguments);
  process.nextTick(function () {
    var candidates = [
      {name: 'Nick', skills: ['JavaScript', 'PHP'], state: 'MO'},
      {name: 'Tim', skills: ['JavaScript', 'PHP'], state: 'TN'}
    ];
    cb(null, candidates);
  });
}

function filterBySkill(skill) {
  return function (candidates, cb) {
    console.log('filterBySkill', arguments);
    candidates = candidates.filter(function (c) {
      return c.skills.indexOf(skill) >= 0;
    });
    cb(null, candidates);
  };
}

function groupByStates(states) {
  var grouped = {};
  states.forEach(function (state) {
    grouped[state] = [];
  });
  return function (candidates, cb) {
    console.log('groupByStates', arguments);
    process.nextTick(function () {
      candidates.forEach(function (c) {
        if (grouped.hasOwnProperty(c.state)) {
          grouped[c.state].push(c);
        }
      });
      cb(null, grouped);
    });
  };
}

var steps = [
  loadCandidates,
  filterBySkill('JavaScript'),
  groupByStates(['MO', 'IL'])
];

var lastPromise = Q();
steps.forEach(function (step) {
  lastPromise = lastPromise.then(function (result) {
    var args = [];
    if (result !== undefined) {
      args.push(result);
    }
    return Q.nfapply(step, args);
  });
});

lastPromise.done(function (grouped) {
  console.log('grouped:', grouped);
}, function (err) {
  console.error(err);
});