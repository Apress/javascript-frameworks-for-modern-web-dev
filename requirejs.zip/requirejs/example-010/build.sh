#!/usr/bin/env bash
../node_modules/.bin/r.js -o rjs-config.js
