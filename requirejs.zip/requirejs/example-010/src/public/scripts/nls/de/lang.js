define({
  pageTitle: 'Grübeleien',
  searchPlaceholder: 'suche'
});