define({
  root: {
    pageTitle: 'Ponderings',
    searchPlaceholder: 'search'
  },
  de: true
});