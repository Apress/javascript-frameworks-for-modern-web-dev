'use strict';

module.exports = {
    'route': '/dashboard',
    'controller': function() {
    },
    'templateUrl': '/app/templates/dashboard.html',
    'resolve': {}
};
