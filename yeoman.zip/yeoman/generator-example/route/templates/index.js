'use strict';

module.exports = {
    'route': '/<%= route %>',
    'controller': function() {
    },
    'templateUrl': '/app/routes/<%= route %>/template.html',
    'resolve': {}
};
